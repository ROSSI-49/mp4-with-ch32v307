#ifndef __IIC_H
#define __IIC_H

#include "debug.h"

void IIC_Init( u32 bound , u16 address );


#endif
