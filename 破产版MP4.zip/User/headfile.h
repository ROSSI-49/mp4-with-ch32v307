/*** 
 * @author          : ROSSI-49
 * @date            : 2023-10-16 22:19
 * @last_editors : ROSSI-49
 * @last_edit_time: 2023-10-16 22:28
 * @path         : \My_Fatfs\User\headfile.h
 * @description     : 用来重新包含所有的头文件
 * @
 * @Copyright (c) 2023 by ROSSI, All Rights Reserved. 
 */

#ifndef SD_DEMO2_HEADFILE_H
#define SD_DEMO2_HEADFILE_H

#include "ch32v30x.h"
#include "sdio.h"
#include "ff.h"
#include "diskio.h"

#endif
